#!/bin/bash

echo "Enter name"
read username

echo "You entered $username"
echo "The characters in $0 $1"

# OutPut
# Enter name
# bhavin
# You entered bhavin
# The characters in ./PassArguments.sh bhavin
